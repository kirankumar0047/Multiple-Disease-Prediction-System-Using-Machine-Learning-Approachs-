# Multiple-Disease-Prediction-System-Using-Machine-Learning-Techniques
● Developed a prediction system for Diabetics, Heart, Breast Cancer, Parkinson’s Diseases.  ● Implemented Streamlit for deploying Prediction System into web application. 
